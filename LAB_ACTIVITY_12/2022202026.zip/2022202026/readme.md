Assumptions:
>>input data = data.txt

>>Assumed walking is started from bottom of mat
>>Assumed walking is done in a straight line to top
>>stride_len is distance between toe and heel of same foot
>>1 step is 1 stride
>>Velocity formula is v = stride_len * (time_differnce of steps)
>>cadence is number of steps per minute (as mentioned in moodle (formula is steps* (seconds)/total_time))