##### 

Implemented Features:-

1. API for creating a new user, login, logout.
2. API for creating new querry,getting all querry by ta rollnumber, getting querry by student roll number.
3. Client has Login,sigup,addquerry,viewquerry.

