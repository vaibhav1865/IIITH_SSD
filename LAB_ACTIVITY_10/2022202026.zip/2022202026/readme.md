###Q1
    input file name: lab_11_data.csv

####Q3
     output file name: average_output.txt
     Each of average is seprated by newline
####Q4
    input is taken from console :character A-Z, design a feature such that all the stocks starting with any
                                 specific alphabet should be displayed
####Q5
     Output file name: stock output.txt