#####
Lab Activity - 6:
####

External File name : logic.js,style.css;

Validations Done : 
Email Valid
Server Username validation
